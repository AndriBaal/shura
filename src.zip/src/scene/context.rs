use std::sync::Arc;

use crate::{
    ComponentManager, FrameManager, Gpu, GpuDefaults, GroupManager, Input, Scene, SceneManager,
    ScreenConfig, Shura, StateManager, Vector, WorldCamera,
};

#[cfg(feature = "serde")]
use crate::{ComponentTypeId, SceneSerializer, SerializedComponentStorage, StateTypeId};

#[cfg(feature = "serde")]
use rustc_hash::FxHashMap;

#[cfg(feature = "audio")]
use crate::audio::AudioManager;

#[cfg(feature = "physics")]
use crate::physics::World;

#[cfg(feature = "gui")]
use crate::gui::Gui;

/// Context to communicate with the game engine to access components, scenes, camera, physics and much more.
pub struct Context<'a> {
    // Scene
    pub scene_id: &'a u32,
    pub scene_started: &'a bool,
    pub update_components: &'a mut i16,
    pub render_components: &'a mut bool,
    pub screen_config: &'a mut ScreenConfig,
    pub scene_states: &'a mut StateManager,
    pub world_camera: &'a mut WorldCamera,
    pub components: &'a mut ComponentManager,
    pub groups: &'a mut GroupManager,
    #[cfg(feature = "physics")]
    pub world: &'a mut World,

    // Shura
    pub frame: &'a FrameManager,
    pub defaults: &'a GpuDefaults,
    pub input: &'a Input,
    pub gpu: Arc<Gpu>,
    #[cfg(feature = "gui")]
    pub gui: &'a Gui,
    #[cfg(feature = "audio")]
    pub audio: &'a AudioManager,
    pub end: &'a mut bool,
    pub scenes: &'a mut SceneManager,
    pub window: &'a mut winit::window::Window,
    pub global_states: &'a mut StateManager,

    // Misc
    pub window_size: Vector<u32>,
}

impl<'a> Context<'a> {
    pub(crate) fn new(shura: &'a mut Shura, scene: &'a mut Scene) -> Context<'a> {
        let mint: mint::Vector2<u32> = shura.window.inner_size().into();
        let window_size = mint.into();
        Self {
            // Scene
            scene_id: &scene.id,
            scene_started: &scene.started,
            render_components: &mut scene.render_components,
            update_components: &mut scene.update_components,
            screen_config: &mut scene.screen_config,
            world_camera: &mut scene.world_camera,
            components: &mut scene.components,
            groups: &mut scene.groups,
            scene_states: &mut scene.states,
            #[cfg(feature = "physics")]
            world: &mut scene.world,

            // Shura
            frame: &shura.frame,
            defaults: &shura.defaults,
            input: &shura.input,
            gpu: shura.gpu.clone(),
            #[cfg(feature = "gui")]
            gui: &shura.gui,
            #[cfg(feature = "audio")]
            audio: &shura.audio,
            end: &mut shura.end,
            scenes: &mut shura.scenes,
            window: &mut shura.window,
            global_states: &mut shura.states,

            // Misc
            window_size,
        }
    }

    #[cfg(feature = "serde")]
    pub fn serialize_scene(
        &mut self,
        mut serialize: impl FnMut(&mut SceneSerializer),
    ) -> Result<Vec<u8>, Box<bincode::ErrorKind>> {
        let components = &self.components;
        let mut serializer =
            SceneSerializer::new(components, &self.global_states, &self.scene_states);
        (serialize)(&mut serializer);

        
        #[derive(serde::Serialize)]
        struct Scene<'a> {
            id: u32,
            update_components: i16,
            started: bool,
            render_components: bool,
            screen_config: &'a ScreenConfig,
            world_camera: &'a WorldCamera,
            components: &'a ComponentManager,
            groups: &'a GroupManager,
            #[cfg(feature = "physics")]
            world: &'a World,
        }

        #[cfg(feature = "physics")]
        {
            let (ser_components, ser_scene_state, ser_global_state) = serializer.finish();
            let mut world_cpy = self.world.clone();
            for ty in self.components.types_mut() {
                if !ser_components.contains_key(&ty.component_type_id()) {
                    match &ty.storage {
                        crate::ComponentTypeStorage::Single { component, .. } => {
                            if let Some(component) = component {
                                world_cpy.remove_no_maintain(component);
                            }
                        }
                        crate::ComponentTypeStorage::Multiple(multiple) => {
                            for component in &multiple.components {
                                world_cpy.remove_no_maintain(component);
                            }
                        }
                        crate::ComponentTypeStorage::MultipleGroups(groups) => {
                            for group in groups {
                                for component in &group.components {
                                    world_cpy.remove_no_maintain(component);
                                }
                            }
                        }
                    }
                }
            }

            let scene = Scene {
                id: *self.scene_id,
                started: true,
                render_components: *self.render_components,
                update_components: *self.update_components,
                screen_config: self.screen_config,
                world_camera: self.world_camera,
                components: self.components,
                groups: self.groups,
                world: &world_cpy,
            };
            let scene: (
                &Scene,
                FxHashMap<ComponentTypeId, SerializedComponentStorage>,
                FxHashMap<StateTypeId, Vec<u8>>,
                FxHashMap<StateTypeId, Vec<u8>>,
            ) = (&scene, ser_components, ser_scene_state, ser_global_state);
            let result = bincode::serialize(&scene);
            return result;
        }

        #[cfg(not(feature = "physics"))]
        {
            let (ser_components, ser_scene_state, ser_global_state) = serializer.finish();
            let scene = Scene {
                id: *self.scene_id,
                started: true,
                screen_config: self.screen_config,
                world_camera: self.world_camera,
                components: self.components,
                groups: self.groups,
                render_components: *self.render_components,
                update_components: *self.update_components,
            };
            let scene: (
                &Scene,
                FxHashMap<ComponentTypeId, SerializedComponentStorage>,
                FxHashMap<StateTypeId, Vec<u8>>,
                FxHashMap<StateTypeId, Vec<u8>>,
            ) = (&scene, ser_components, ser_scene_state, ser_global_state);
            let result = bincode::serialize(&scene);
            return result;
        }
    }
}
