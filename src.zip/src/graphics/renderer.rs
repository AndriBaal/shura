use crate::{
    CameraBuffer, Color, Gpu, GpuDefaults, InstanceBuffer, InstanceIndices, Model, RenderCamera,
    RenderConfigInstances, RenderTarget, Shader, Sprite, SpriteSheet, Uniform, Vector, RenderEncoder,
};
use std::ops::Range;

#[cfg(feature = "text")]
use crate::text::{FontBrush, TextSection};

pub struct RenderPresenter<'a, 'b> {
    pub gpu: &'a Gpu,
    pub defaults: &'a GpuDefaults,
    target: &'a RenderTarget,
    render_pass: wgpu::RenderPass<'b>,
    msaa: bool,
}

impl<'a: 'b, 'b> RenderPresenter<'a, 'b> {
    pub(crate) fn new(
        encoder: &'a mut RenderEncoder,
        target: &'a RenderTarget,
        msaa: bool,
        clear: Option<Color>,
    ) -> RenderPresenter<'a, 'b> {
        let render_pass = encoder.inner.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: Some("render_pass"),
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view: if msaa { target.msaa() } else { target.view() },
                resolve_target: if msaa { Some(target.view()) } else { None },
                ops: wgpu::Operations {
                    load: if let Some(clear_color) = clear {
                        wgpu::LoadOp::Clear(clear_color.into())
                    } else {
                        wgpu::LoadOp::Load
                    },
                    store: true,
                },
            })],

            depth_stencil_attachment: None,
        });

        return Self {
            render_pass,
            msaa: msaa,
            defaults: encoder.defaults,
            gpu: encoder.gpu,
            target,
        };
    }

    pub(crate) fn output_renderer(
        encoder: &'a mut wgpu::CommandEncoder,
        output: &'a wgpu::TextureView,
        defaults: &'a GpuDefaults,
    ) {
        let mut render_pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: Some("render_pass"),
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view: &output,
                resolve_target: None,
                ops: wgpu::Operations {
                    load: wgpu::LoadOp::Load,
                    store: true,
                },
            })],

            depth_stencil_attachment: None,
        });

        let shader = &defaults.sprite_no_msaa;
        let sprite = &defaults.world_target.sprite();
        let model = &defaults.relative_camera.0.model();

        render_pass.set_bind_group(
            Renderer::CAMERA_SLOT,
            &defaults.relative_camera.0.uniform().bind_group(),
            &[],
        );
        render_pass.set_vertex_buffer(
            Renderer::INSTANCE_SLOT,
            defaults.single_centered_instance.slice(),
        );
        render_pass.set_pipeline(shader.pipeline());
        render_pass.set_bind_group(1, sprite.bind_group(), &[]);
        render_pass.set_vertex_buffer(Renderer::MODEL_SLOT, model.vertex_buffer().slice(..));
        render_pass.set_index_buffer(model.index_buffer().slice(..), wgpu::IndexFormat::Uint32);
        render_pass.draw_indexed(0..model.amount_of_indices(), 0, 0..1);

        // renderer.use_camera_buffer(&defaults.relative_camera.0);
        // renderer.use_instance_buffer(&defaults.single_centered_instance);
        // renderer.use_shader(&ctx.defaults.sprite_no_msaa);
        // renderer.use_model(ctx.defaults.relative_camera.0.model());
        // renderer.use_sprite(ctx.defaults.world_target.sprite(), 1);
        // renderer.draw(0);
    }

    pub fn renderer(&self) -> Renderer<'a> {
        let bundle =
            self.gpu
                .device
                .create_render_bundle_encoder(&wgpu::RenderBundleEncoderDescriptor {
                    label: None,
                    color_formats: &[Some(wgpu::TextureFormat::Rgba8UnormSrgb)],
                    depth_stencil: None,
                    sample_count: if self.msaa {
                        self.gpu.base.sample_count
                    } else {
                        1
                    },
                    multiview: None,
                });
        return Renderer {
            bundle,
            indices: 0,
            msaa: self.msaa,
            defaults: self.defaults,
            target: self.target,
            gpu: self.gpu,
            screenshot: None,
        };
    }
}

/// Render grpahics to the screen or a sprite. The renderer can be extended with custom graphcis throught
/// the [RenderPass](wgpu::RenderPass) or the provided methods for shura's shader system.
pub struct Renderer<'a> {
    pub gpu: &'a Gpu,
    pub defaults: &'a GpuDefaults,
    target: &'a RenderTarget,
    msaa: bool,
    indices: u32,
    bundle: wgpu::RenderBundleEncoder<'a>,
    screenshot: Option<&'a RenderTarget>,
}

impl<'a> Renderer<'a> {
    pub const MODEL_SLOT: u32 = 0;
    pub const INSTANCE_SLOT: u32 = 1;
    pub const CAMERA_SLOT: u32 = 0;
    // pub fn new(
    //     defaults: &'a GpuDefaults,
    //     gpu: &'a Gpu,
    //     target: &'a RenderTarget,
    //     msaa: bool,
    //     clear: Option<Color>,
    // ) -> Renderer<'a> {

    // }

    pub fn target(&self) -> &RenderTarget {
        self.target
    }

    /// Sets the instance buffer at the position 1
    pub fn use_instance_buffer(&mut self, buffer: &'a InstanceBuffer) {
        self.bundle
            .set_vertex_buffer(Self::INSTANCE_SLOT, buffer.slice());
    }

    pub fn use_camera_buffer(&mut self, camera: &'a CameraBuffer) {
        self.bundle
            .set_bind_group(Self::CAMERA_SLOT, camera.uniform().bind_group(), &[]);
    }

    pub fn use_instances(&mut self, instances: RenderConfigInstances<'a>) {
        let buffer = instances.instances(self.defaults);
        self.use_instance_buffer(buffer);
    }

    pub fn use_camera(&mut self, camera: RenderCamera<'a>) {
        let buffer = camera.camera(self.defaults);
        self.use_camera_buffer(buffer);
    }

    pub fn use_shader(&mut self, shader: &'a Shader) {
        assert_eq!(
            shader.msaa(),
            self.msaa,
            "The Renderer and the Shader both need to have msaa enabled / disabled!"
        );
        self.bundle.set_pipeline(shader.pipeline());
    }

    pub fn use_model(&mut self, model: &'a Model) {
        self.indices = model.amount_of_indices();
        self.bundle
            .set_index_buffer(model.index_buffer().slice(..), wgpu::IndexFormat::Uint32);
        self.bundle
            .set_vertex_buffer(Self::MODEL_SLOT, model.vertex_buffer().slice(..));
    }

    pub fn use_sprite(&mut self, sprite: &'a Sprite, slot: u32) {
        self.use_bind_group(sprite.bind_group(), slot);
    }

    pub fn use_sprite_sheet(&mut self, sprite_sheet: &'a SpriteSheet, slot: u32) {
        self.use_bind_group(sprite_sheet.bind_group(), slot);
    }

    pub fn use_uniform<T: bytemuck::Pod>(&mut self, uniform: &'a Uniform<T>, slot: u32) {
        self.use_bind_group(uniform.bind_group(), slot);
    }

    pub fn use_bind_group(&mut self, bind_group: &'a wgpu::BindGroup, slot: u32) {
        self.bundle.set_bind_group(slot, bind_group, &[]);
    }

    pub fn draw(&mut self, instances: impl Into<InstanceIndices>) {
        self.draw_indexed(0..self.indices, instances);
    }

    pub fn draw_indexed(&mut self, indices: Range<u32>, instances: impl Into<InstanceIndices>) {
        self.bundle.draw_indexed(indices, 0, instances.into().range);
    }

    pub const fn msaa(&self) -> bool {
        self.msaa
    }

    #[cfg(feature = "text")]
    pub fn render_font(&mut self, font: &'a FontBrush) {
        font.render(self.gpu, &mut self.bundle, self.target.size().cast::<f32>())
    }

    #[cfg(feature = "text")]
    pub fn queue_text(
        &mut self,
        camera: RenderCamera,
        font: &'a FontBrush,
        sections: Vec<TextSection>,
    ) {
        font.queue(self.defaults, camera, self.target.size(), sections);
    }

    pub fn render_sprite(
        &mut self,
        instances: impl Into<InstanceIndices>,
        model: &'a Model,
        sprite: &'a Sprite,
    ) {
        self.use_shader(&self.defaults.sprite);
        self.use_model(model);
        self.use_sprite(sprite, 1);
        self.draw(instances);
    }

    pub fn render_sprite_sheet(
        &mut self,
        instances: impl Into<InstanceIndices>,
        model: &'a Model,
        sprite: &'a SpriteSheet,
    ) {
        self.use_shader(&self.defaults.sprite_sheet);
        self.use_model(model);
        self.use_sprite_sheet(sprite, 1);
        self.draw(instances);
    }

    pub fn render_sprite_sheet_uniform(
        &mut self,
        instances: impl Into<InstanceIndices>,
        model: &'a Model,
        sprite: &'a SpriteSheet,
        sprite_index: &'a Uniform<Vector<i32>>,
    ) {
        self.use_shader(&self.defaults.sprite_sheet_uniform);
        self.use_model(model);
        self.use_sprite_sheet(sprite, 1);
        self.use_uniform(sprite_index, 2);
        self.draw(instances);
    }

    pub fn render_color(&mut self, instances: impl Into<InstanceIndices>, model: &'a Model) {
        self.use_shader(&self.defaults.color);
        self.use_model(model);
        self.draw(instances);
    }

    pub fn render_color_uniform(
        &mut self,
        instances: impl Into<InstanceIndices>,
        model: &'a Model,
        color: &'a Uniform<Color>,
    ) {
        self.use_shader(&self.defaults.color_uniform);
        self.use_model(model);
        self.use_uniform(color, 1);
        self.draw(instances);
    }

    pub fn render_grey(
        &mut self,
        instances: impl Into<InstanceIndices>,
        model: &'a Model,
        sprite: &'a Sprite,
    ) {
        self.use_shader(&self.defaults.grey);
        self.use_model(model);
        self.use_sprite(sprite, 1);
        self.draw(instances);
    }

    pub fn render_blurred(
        &mut self,
        instances: impl Into<InstanceIndices>,
        model: &'a Model,
        sprite: &'a Sprite,
    ) {
        self.use_shader(&self.defaults.blurr);
        self.use_model(model);
        self.use_sprite(sprite, 1);
        self.draw(instances);
    }

    pub fn render_sprite_no_msaa(
        &mut self,
        instances: impl Into<InstanceIndices>,
        model: &'a Model,
        sprite: &'a Sprite,
    ) {
        self.use_shader(&self.defaults.sprite_no_msaa);
        self.use_model(model);
        self.use_sprite(sprite, 1);
        self.draw(instances);
    }

    pub fn render_rainbow(&mut self, instances: impl Into<InstanceIndices>, model: &'a Model) {
        self.use_shader(&self.defaults.rainbow);
        self.use_model(model);
        self.use_uniform(&self.defaults.times, 1);
        self.draw(instances);
    }
}
